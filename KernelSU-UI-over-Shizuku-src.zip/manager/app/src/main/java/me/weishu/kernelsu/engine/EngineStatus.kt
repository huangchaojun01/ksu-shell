package me.weishu.kernelsu.engine

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import rikka.shizuku.Shizuku

/**
 * EngineStatus —— 给 Home / Settings 读的 "状态卡片" 数据源.
 * 对应方案 §4.3: 把 "KernelSU 版本/内核版本" 替换为 Shizuku 服务维度.
 *
 * 使用的 Shizuku 公开 API (rikka.shizuku.Shizuku):
 *   - pingBinder(): Boolean          服务是否存活
 *   - getUid(): Int                  服务端 UID (0=Root, 2000=ADB/Shell)
 *   - getServerApiVersion(): Int     服务端 API 版本
 *   - getServerVersion(): Int        服务端版本号
 *  详见: https://github.com/RikkaApps/Shizuku-API
 */
object EngineStatus {

    val state: MutableState<State> = mutableStateOf(State.Stopped)

    /** 供 Home.kt StatusCard 显示 (原 Natives.getVersion()) */
    val versionCode: Int
        get() = if (Shizuku.pingBinder()) Shizuku.getServerApiVersion() else 0

    val versionName: String
        get() = if (Shizuku.pingBinder()) {
            val v = Shizuku.getServerVersion()
            "Shizuku $v (bridged)"
        } else "Stopped"

    val isSafeMode: Boolean get() = state.value != State.Running
    val isRunning: Boolean get() = state.value == State.Running

    // 对应 Settings 内核特性开关 → engine 等价开关
    var suCompatible: Boolean = true
    var kernelUmount: Boolean = false

    /** 由 Shizuku 回调 / EngineServiceConnector 驱动 */
    fun refresh() {
        state.value = if (!Shizuku.pingBinder()) {
            State.Stopped
        } else if (Shizuku.getUid() == 0) {
            State.Running   // Root 模式归到 Running (ADB/Root 差异见 ShizukuCompat)
        } else {
            State.Running
        }
        // 注: ADB (uid=2000) vs ROOT (uid=0) 的细分由 ShizukuCompat 负责,
        //     State 仅表达 "服务是否在跑", 保持与 KernelSU 状态卡片 1:1 映射.
    }

    enum class State { Stopped, Running }
}
