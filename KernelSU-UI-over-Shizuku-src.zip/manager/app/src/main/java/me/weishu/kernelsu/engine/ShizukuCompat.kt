package me.weishu.kernelsu.engine

import rikka.shizuku.Shizuku

/**
 * ShizukuCompat —— 屏蔽 ADB (uid=2000) / ROOT (uid=0) 差异.
 * 对应方案 §4.6: "能否做 X" 在 ADB 权限受限时降级, UI 弹提示而非崩溃.
 *
 * 真实 Shizuku 公开 API: Shizuku.getUid()
 *   - 0    → Root (Sui / root 启动的 server)
 *   - 2000 → ADB / Shell (权限受限, 无法访问其他 App 数据 / 改 SELinux 强制策略)
 *  参考: Shizuku README "ADB permissions are limited"
 */
object ShizukuCompat {

    /** 服务端 UID (0=root, 2000=shell). 未连接时兜底 2000 (视作受限). */
    val uid: Int
        get() = if (Shizuku.pingBinder()) Shizuku.getUid() else 2000

    val isRoot: Boolean get() = uid == 0
    val isAdb: Boolean get() = uid == 2000

    /** 需要 root 能力时: root 直接执行, 否则走降级回调 */
    inline fun requirePrivilege(block: () -> Unit, onLimited: () -> Unit) {
        if (isRoot) block() else onLimited()
    }

    /** 当前权限模式描述 (供 Settings 显示) */
    fun modeDescription(): String = when {
        !Shizuku.pingBinder() -> "Stopped"
        isRoot -> "ROOT (uid 0)"
        isAdb -> "ADB (uid 2000, limited)"
        else -> "uid=$uid"
    }
}
