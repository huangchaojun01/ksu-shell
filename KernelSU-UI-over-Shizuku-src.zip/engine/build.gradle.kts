plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "me.weishu.kernelsu.engine.test"
    compileSdk = 36
    defaultConfig { minSdk = 26 }
    sourceSets {
        test {
            java.srcDirs = ["src/test/java"]
        }
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    implementation(project(":manager:app"))
}
