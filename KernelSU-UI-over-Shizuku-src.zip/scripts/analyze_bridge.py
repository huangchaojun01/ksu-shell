#!/usr/bin/env python3
"""
桥接引用图静态分析器 (不依赖 Android SDK)

功能: 扫描所有 .kt, 构建 "调用方 → 桥接层 → Shizuku API" 的引用图,
     验证方案 §3 语义映射表全部落地, 且无断链.
"""
import re, os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "manager/app/src/main/java/me/weishu/kernelsu"

# 方案 §3 期望的语义映射: KernelSU语义 → Shizuku能力 → 落地文件
# 所有路径均相对于 APP 根 (manager/app/src/main/java/me/weishu/kernelsu/)
EXPECTED = {
    "授权 App (allowSu) → Shizuku checkSelfPermission + 本地镜像": {
        "file": "engine/EnginePermissionStore.kt",
        "must_contain": ["Shizuku.checkSelfPermission", "SharedPreferences", "allowSu", "grant", "revoke"],
    },
    "Root/su 原语 → ShizukuBinderWrapper": {
        "file": "engine/BinderForwarder.kt",
        "must_contain": ["ShizukuBinderWrapper", "SystemServiceHelper"],
    },
    "Module → UserService": {
        "file": "engine/EngineModuleBridge.kt",
        "must_contain": ["bindUserService", "IModuleUserService"],
    },
    "状态卡片 → EngineStatus (pingBinder/getUid)": {
        "file": "engine/EngineStatus.kt",
        "must_contain": ["Shizuku.pingBinder", "Shizuku.getServerApiVersion", "State.Running"],
    },
    "ADB/ROOT 兼容 → ShizukuCompat (uid 0/2000)": {
        "file": "engine/ShizukuCompat.kt",
        "must_contain": ["isRoot", "isAdb", "Shizuku.getUid"],
    },
    "自启/ADB 启动 → ServiceConnector": {
        "file": "engine/EngineServiceConnector.kt",
        "must_contain": ["ensureStarted", "startWithRoot", "startWithAdb"],
    },
    "入口 init → Engine.init": {
        "file": "KernelSUApplication.kt",
        "must_contain": ["Engine.init"],
    },
    "MainActivity → ensureStarted": {
        "file": "ui/MainActivity.kt",
        "must_contain": ["Engine.serviceConnector.ensureStarted"],
    },
    "Natives 桩 → permissionStore": {
        "file": "Natives.kt",
        "must_contain": ["Engine.permissionStore", "getAllowList", "Profile("],
    },
    "ModuleViewModel → moduleBridge": {
        "file": "viewmodel/ModuleViewModel.kt",
        "must_contain": ["Engine.moduleBridge"],
    },
    "SuperUserViewModel → EnginePermissionStore": {
        "file": "viewmodel/SuperUserViewModel.kt",
        "must_contain": ["Natives.getAppProfile", "Natives.setAppProfile"],
    },
}


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8") if p.exists() else ""


def resolve(rel: str) -> Path:
    # 所有路径相对于 APP 根
    return (APP / rel).resolve()


def main():
    print("== 桥接引用图静态分析 ==")
    print(f"扫描根: {APP}\n")
    all_ok = True
    results = []

    for sem, spec in EXPECTED.items():
        path = resolve(spec["file"])
        src = read(path)
        if not src:
            results.append((sem, "MISSING_FILE", path))
            all_ok = False
            continue
        missing = [m for m in spec["must_contain"] if m not in src]
        status = "OK" if not missing else f"MISSING_TOKENS {missing}"
        if missing:
            all_ok = False
        results.append((sem, status, path))

    # 打印引用图
    print("调用链 (KernelSU语义 → 落地文件 → Shizuku API):")
    for sem, status, path in results:
        rel = path.relative_to(ROOT)
        print(f"  [{status:14}] {sem}")
        print(f"              ↳ {rel}")

    # 额外: 检查 Shizuku API 符号被引用的分布
    print("\nShizuku API 引用分布:")
    api_symbols = ["Shizuku", "ShizukuBinderWrapper", "SystemServiceHelper",
                   "ShizukuSettings", "ShizukuService", "bindUserService", "pingBinder", "getUid"]
    for sym in api_symbols:
        count = 0
        files = []
        for kt in APP.rglob("*.kt"):
            if sym in kt.read_text(encoding="utf-8", errors="ignore"):
                count += 1
                files.append(str(kt.relative_to(ROOT)))
        print(f"  {sym:24}: {count} 处  {files}")

    # 循环/反向依赖检查: engine/ 不应被 theme/component/ui(screen) 直接引用非桥接类
    print("\n架构约束检查:")
    violations = []
    for kt in (APP / "engine").rglob("*.kt"):
        src = kt.read_text(encoding="utf-8", errors="ignore")
        # engine 内部不应反向 import ui/screen/component (只允许 import Natives/Engine)
        for bad in ["ui.screen", "ui.component", "theme.", "component."]:
            if f"import me.weishu.kernelsu.{bad}" in src:
                violations.append((str(kt.relative_to(ROOT)), bad))
    if violations:
        print("  [VIOLATION] engine/ 反向依赖 UI 层:")
        for v in violations:
            print(f"    - {v[0]} → {v[1]}")
        all_ok = False
    else:
        print("  [OK] engine/ 无反向依赖 (单向桥接)")

    print("\n" + ("== 全部语义映射已落地 ✅ ==" if all_ok else "== 存在问题 ❌ =="))
    exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
