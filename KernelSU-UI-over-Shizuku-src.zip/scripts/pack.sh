#!/usr/bin/env bash
# 打包源码为 zip (排除 build/、.gradle/、engine-src/、*.apk)
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

OUT="/data/workspace/KernelSU-UI-over-Shizuku-src.zip"
rm -f "$OUT"

# 依据 manifest 精确打包 (保证交付完整、无垃圾)
exec 3< scripts/manifest.txt
while read -r f <&3; do
    [[ -z "$f" || "$f" == \#* ]] && continue
    if [ -e "$f" ]; then
        zip -q "$OUT" "$f"
    else
        echo "  [WARN] manifest 列出但文件不存在: $f"
    fi
done
exec 3<&-

echo ""
echo "== 打包完成 =="
unzip -l "$OUT" | tail -3
echo ""
echo "文件: $OUT"
