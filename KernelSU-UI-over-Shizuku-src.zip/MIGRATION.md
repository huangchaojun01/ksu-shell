# 迁移指南：补齐 KernelSU 完整 UI

脚手架已就绪，下面是把它变成**完整可编译工程**的 3 步。
桥接层（`engine/`）、改动点（`KernelSUApplication`/`Natives`/`MainActivity`/ViewModel）**不要动**。

## 前置

- JDK 17、Android SDK (platform-36, build-tools 36.0.0)、环境变量 `ANDROID_HOME`

## 第 1 步：拉取 KernelSU v3.2.3 外壳 UI（不动 UI，仅拷贝）

```bash
cd KernelSU-UI-over-Shizuku
git clone --depth 1 --branch v3.2.3 https://github.com/tiann/KernelSU tmp-ksu
KSU=tmp-ksu/manager/app/src/main
APP=manager/app/src/main

# ★ 拷贝完整 UI (theme/component/navigation/ui/screen 全覆盖, 方案承诺: UI 零删减)
cp -R $KSU/java/me/weishu/kernelsu/ui     $APP/java/me/weishu/kernelsu/
cp -R $KSU/java/me/weishu/kernelsu/theme  $APP/java/me/weishu/kernelsu/
cp -R $KSU/java/me/weishu/kernelsu/component $APP/java/me/weishu/kernelsu/
cp -R $KSU/java/me/weishu/kernelsu/navigation $APP/java/me/weishu/kernelsu/
cp -R $KSU/java/me/weishu/kernelsu/util   $APP/java/me/weishu/kernelsu/
cp -R $KSU/res                            $APP/   # 覆盖脚手架的占位 res (保留 themes.xml!)
```

> ⚠️ **保留脚手架的桥接改动**：上述 `cp` 会覆盖同名文件。
> `KernelSUApplication.kt` / `Natives.kt` / `MainActivity.kt` / `SuperUserViewModel.kt` / `ModuleViewModel.kt`
> 这 5 个文件**必须保留本脚手架版本**（已在 `engine/` 桥接）。
> 若 KSU 原版覆盖了它们，把本脚手架对应文件重新拷回即可。

## 第 2 步：接入 Shizuku 源码（核心，零改动）

```bash
# 方式 A: 源码平铺 (推荐, 可审计)
git clone --depth 1 https://github.com/RikkaApps/Shizuku engine-src
for mod in api manager server starter; do
  cp -R engine-src/$mod/* engine/$mod/
done
rm -rf engine-src
# 取消各 engine/*/build.gradle 里 sourceSets 的注释 (指向 ../../Shizuku/...)

# 方式 B: 纯远程依赖 (更简单)
# 只需在 manager/app/build.gradle.kts 保留 implementation(libs.shizuku.api) 等,
# 删除 settings.gradle 里的 engine-* include, 删除 engine/ 目录即可
```

## 第 3 步：合并依赖 (build.gradle.kts)

KSU 原版 `manager/app/build.gradle.kts` 已有 Compose/Miuix/导航依赖。
**在其基础上追加**本脚手架 `build.gradle.kts` 的：

- `namespace = "me.weishu.kernelsu"`、`applicationId = "me.weishu.kernelsu"`（**必须锁死**）
- `buildFeatures { compose = true; aidl = true }`
- `dependencies` 里的 `shizuku-api`、`shizuku-provider`、engine 模块
- `versionName = "3.2.3-bridge"`

## 第 4 步：编译

```bash
./gradlew :manager:app:assembleRelease
# 产物: manager/app/build/outputs/apk/release/app-release-unsigned.apk
```

## 校验（方案 §5.3 单 APK 原则）

```bash
APK=manager/app/build/outputs/apk/release/*.apk
unzip -l $APK | grep -E "libshizuku|libadb|classes.jar|ic_launcher"
aapt dump badging $APK | grep -E "application-label|launchable-activity|package"
# 期望: label=KernelSU, launchable=me.weishu.kernelsu.ui.MainActivity, 含 Shizuku native libs
```

## 预期冲突 & 处理

| 冲突 | 处理 |
|---|---|
| KSU 原 `Natives.kt` 有 `external fun` (JNI) | **用脚手架版本替换**, 去掉 `loadLibrary("kernelsu")` |
| KSU 原 `KernelSUApplication` 有 `HiddenApiBypass` | 保留调用, 仅在 onCreate 首行加 `Engine.init(this)` |
| `BuildConfig.DEBUG` 找不到 | 确认 `build.gradle.kts` 有 `buildConfig true` (AGP 8 默认) |
| Shizuku `aidl` 生成类找不到 | `engine-api` 模块的 `buildFeatures { aidl = true }` |
| 图标/字符串重复 | 以 KSU `res/` 为准, 删脚手架占位 `themes.xml` 之外的文件 |

完成后：**App 看起来 100% 是 KernelSU，底层 100% 是 Shizuku**。
