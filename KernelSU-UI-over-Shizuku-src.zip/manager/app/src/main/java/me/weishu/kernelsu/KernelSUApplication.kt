package me.weishu.kernelsu

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import me.weishu.kernelsu.engine.Engine

/**
 * KernelSUApplication —— 外壳 Application.
 * 对应方案 §4.1: 原 KSU init (HiddenApiBypass / libsu / loadLibrary("kernelsu"))
 *   → 替换为 Shizuku 引擎初始化, 外部行为 (包名/主题/icon) 100% KernelSU.
 */
class KernelSUApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // ★ 桥接核心: 启动 Shizuku 引擎 (来自 engine/manager, 核心零改动)
        Engine.init(this)

        // 主题 (locale / night mode) —— KSU 原逻辑, 原样保留
        val nightMode =  /* 原: Natives.getNightMode() */ AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }
}
