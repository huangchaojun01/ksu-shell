#!/usr/bin/env bash
# 一键构建脚本 (本地, 需已配置 ANDROID_HOME + JDK 17)
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "== KernelSU-UI-over-Shizuku 构建 =="

# 0) 环境检查
command -v java >/dev/null || { echo "缺少 java"; exit 1; }
java -version 2>&1 | grep -q "17\." || echo "⚠ 建议 JDK 17 (AGP 8 需要), 当前:"
[ -n "$ANDROID_HOME" ] || { echo "请先 export ANDROID_HOME"; exit 1; }

# 1) 接入 Shizuku 源码 (核心, 零改动) —— 若尚未接入
if [ ! -f engine/api/src/main/AndroidManifest.xml ] && [ ! -d engine-src ]; then
    echo "-- 拉取 Shizuku 源码 (核心零改动) --"
    git clone --depth 1 https://github.com/RikkaApps/Shizuku engine-src
    # 取消各 engine/*/build.gradle 里 sourceSets 注释, 指向 engine-src 对应目录
    for mod in api manager server starter; do
        sed -i "s|../../Shizuku/$mod|../engine-src/$mod|g" engine/$mod/build.gradle
        sed -i 's|^// \(java.srcDirs\)|\1|; s|^// \(res.srcDirs\)|\1|; s|^// \(manifest.srcFile\)|\1|' engine/$mod/build.gradle
    done
    echo "已配置 engine/ 模块指向 Shizuku 源码"
fi

# 2) 拷贝 KernelSU UI 资源 (外壳, 不动) —— 提示用户手动拷贝
if [ ! -d manager/app/src/main/res ]; then
    echo ""
    echo "⚠ 请先拷贝 KernelSU v3.2.3 的资源到 manager/app/src/main/ :"
    echo "    git clone --branch v3.2.3 https://github.com/tiann/KernelSU tmp-ksu"
    echo "    cp -r tmp-ksu/manager/app/src/main/{ui,res,theme,component} manager/app/src/main/"
    echo "    cp tmp-ksu/manager/app/build.gradle.kts manager/app/build.gradle.kts.bak  # 保留我们的依赖块"
    echo ""
fi

# 3) 构建
echo "-- gradle assembleRelease --"
./gradlew :manager:app:assembleRelease "$@"

# 4) 校验 (方案 §5.3)
APK=$(ls manager/app/build/outputs/apk/release/*.apk 2>/dev/null | head -1)
if [ -n "$APK" ]; then
    echo ""
    echo "-- 校验产物 (单 APK 原则, §5.3) --"
    unzip -l "$APK" | grep -E "libshizuku|libadb|classes.jar|ic_launcher" || echo "· 检查 native libs / assets"
    $ANDROID_HOME/build-tools/36.0.0/aapt dump badging "$APK" 2>/dev/null | grep -E "application-label|launchable-activity|package" || true
    echo ""
    echo "✅ 产物: $APK"
fi
