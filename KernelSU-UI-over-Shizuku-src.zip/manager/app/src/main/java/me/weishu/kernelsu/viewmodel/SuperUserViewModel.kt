package me.weishu.kernelsu.viewmodel

import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import me.weishu.kernelsu.Natives

/**
 * SuperUserViewModel —— 授权 App 列表.
 * 对应方案 §4.4: UI (LazyColumn / AppItem / SearchAppBar / Profile 编辑器) 完全不动,
 *   **仅改数据源**: PackageManager + EnginePermissionStore.
 */
class SuperUserViewModel : ViewModel() {

    val apps: MutableState<List<AppInfo>> = mutableStateOf(emptyList())

    fun fetchAppList(context: Context) {
        val pm = context.packageManager
        // ★ 改动点: 授权态来自 EnginePermissionStore (原: IKsuInterface.Stub + Natives.getAppProfile)
        apps.value = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
            .map { pkg ->
                AppInfo(
                    label = pkg.applicationInfo.loadLabel(pm).toString(),
                    packageInfo = pkg,
                    profile = Natives.getAppProfile(null, pkg.applicationInfo.uid)  // ← 唯一改动点
                )
            }
    }

    /** "授权/撤销" 开关 —— UI onClick 调 setAppProfile, 已在 Natives.setAppProfile 内转发 */
    fun toggleAllow(app: AppInfo, allowed: Boolean) {
        val uid = app.packageInfo.applicationInfo.uid
        val pkg = app.packageInfo.packageName
        val profile = Natives.getAppProfile(null, uid).copy(allowSu = allowed, packageName = pkg)
        Natives.setAppProfile(profile)
    }
}

data class AppInfo(
    val label: String,
    val packageInfo: android.content.pm.PackageInfo,
    val profile: Natives.Profile,
)
