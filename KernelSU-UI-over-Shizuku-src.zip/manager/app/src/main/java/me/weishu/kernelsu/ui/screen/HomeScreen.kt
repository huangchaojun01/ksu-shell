package me.weishu.kernelsu.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import me.weishu.kernelsu.engine.Engine

/**
 * 外壳页面 (KernelSU UI, 原样保留).
 * 此处为最小占位骨架, 实际应从 KernelSU v3.2.3 完整拷贝 ui/screen/*.
 * 桥接改动仅在数据源 (Engine.*), Composable 结构不动.
 */
@Composable
fun HomeScreen() {
    val status by Engine.status.state
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("KernelSU", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Engine: ${Engine.status.versionName}")
        Text("Mode: ${Engine.compat.modeDescription()}")
        Text("Status: $status")
    }
}

@Composable
fun SuperUserScreen() { Text("SuperUser") }

@Composable
fun ModuleScreen() { Text("Module") }

@Composable
fun SettingsScreen() { Text("Settings") }
