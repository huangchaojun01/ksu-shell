package me.weishu.kernelsu.util

/**
 * 工具扩展 (外壳, 原样保留).
 * 此处为占位, 实际应从 KernelSU v3.2.3 manager 拷贝完整实现.
 */
inline fun <T> runCatching(block: () -> T): Result<T> = kotlin.runCatching(block)
