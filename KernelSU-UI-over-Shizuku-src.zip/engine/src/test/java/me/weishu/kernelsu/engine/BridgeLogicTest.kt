package me.weishu.kernelsu.engine

import org.junit.Test
import org.junit.Assert.*

/**
 * 桥接逻辑纯 JVM 测试 (不依赖 Android SDK):
 * 验证 Natives 桩 → EnginePermissionStore → Profile 的数据流转,
 * 对应方案 §4.2 / §4.4 的核心语义.
 */
class BridgeLogicTest {

    @Test
    fun `Natives Profile 字段签名保留, allowSu 为授权核心标志`() {
        val profile = Natives.Profile(
            uid = 10086,
            allowSu = true,
            packageName = "com.example.app"
        )
        assertTrue(profile.allowSu)
        assertEquals(10086, profile.uid)
        // 未设置字段保持默认 (语义映射不破坏原有结构)
        assertEquals(0, profile.gid)
        assertEquals("", profile.sepolicy)
    }

    @Test
    fun `EngineStatus 状态机映射正确`() {
        // Stopped (初始) → Running (pingBinder 后)
        assertEquals(EngineStatus.State.Stopped, EngineStatus.state.value)
        // versionCode 在未连接时返回 0 (runCatching 兜底)
        assertTrue(EngineStatus.versionCode >= 0)
    }

    @Test
    fun `ShizukuCompat ADB-ROOT 差异逻辑`() {
        // 默认 (无 Shizuku binder) uid=2000 兜底 → isAdb
        // 真实设备上由 Shizuku.getUid() 驱动; 此处仅验证分支不抛异常
        val desc = ShizukuCompat.modeDescription()
        assertNotNull(desc)
        // 未连接时应报告 Stopped
        assertTrue(desc.contains("Stopped") || desc.contains("uid="))
    }

    @Test
    fun `桥接核心 API 符号存在性 (编译期契约)`() {
        // 这些符号若被重命名/删除, 编译即失败 —— 作为桥接契约的轻量断言
        assertNotNull(Engine.permissionStore)
        assertNotNull(Engine.moduleBridge)
        assertNotNull(Engine.status)
        assertNotNull(Engine.compat)
        assertNotNull(Engine.binder)
        assertNotNull(Engine.serviceConnector)
    }
}
