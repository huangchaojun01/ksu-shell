package me.weishu.kernelsu.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * KernelSU 主题 (外壳, 原样保留).
 * 对应方案 §3.2: Miuix + Material3, 品牌色 @color/kernelsu_green.
 */
private val LightColors = lightColorScheme(
    primary = Color(0xFF1A7F5A),
    secondary = Color(0xFF0E5C40),
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DBF96),
    secondary = Color(0xFF1A7F5A),
)

@Composable
fun KernelSUTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
