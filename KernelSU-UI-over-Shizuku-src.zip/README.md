# KernelSU-UI-over-Shizuku

> App 看起来 100% 是 KernelSU，底层 100% 是 Shizuku 在干活。

本仓库 = **可编译的工程脚手架**。完整构建只需 3 步（详见 [MIGRATION.md](MIGRATION.md)）：

```bash
# 1) 拷贝 KernelSU v3.2.3 UI (不动 UI, 仅覆盖 theme/component/ui/screen)
# 2) 接入 Shizuku 源码 (核心零改动)  → engine/{api,manager,server,starter}
# 3) ./gradlew :manager:app:assembleRelease
```

**未执行迁移前**，可先跑静态验证（无需 Android SDK / Gradle）：

```bash
bash scripts/verify_structure.sh     # 结构自检
python3 scripts/analyze_bridge.py    # 桥接引用图 (11 项语义映射)
python3 scripts/check_references.py  # 符号引用解析 (64 引用, 0 断链)
```

## 目录结构

```
KernelSU-UI-over-Shizuku/
├── settings.gradle / build.gradle / gradle.properties / .gitignore
├── gradle/libs.versions.toml        # 依赖坐标 (含 shizuku-api)
├── Dockerfile                        # 可复现构建环境
├── README.md / MIGRATION.md         # 本文件 / 迁移指南
├── manager/app/                     # ★ 外壳 = KernelSU manager
│   ├── build.gradle.kts             # namespace/applicationId 锁 me.weishu.kernelsu
│   └── src/main/
│       ├── AndroidManifest.xml      # KSU 宿主 + Shizuku 组件合并
│       ├── res/                     # 占位 (迁移时被 KSU res/ 覆盖, 保留 themes.xml)
│       └── java/me/weishu/kernelsu/
│           ├── KernelSUApplication.kt   # 改: KSU init → Engine.init
│           ├── Natives.kt               # 改: JNI 桩 → 转发 engine (§4.2)
│           ├── engine/                  # ★ 桥接层 (唯一新增, 7 文件)
│           │   ├── Engine.kt                 # 单例
│           │   ├── EnginePermissionStore.kt  # 授权 → checkSelfPermission + 本地镜像
│           │   ├── EngineModuleBridge.kt     # Module → UserService
│           │   ├── EngineStatus.kt           # Home/Settings 状态卡片
│           │   ├── EngineServiceConnector.kt # 自启/ADB 启动
│           │   ├── ShizukuCompat.kt          # ADB(2000)/ROOT(0) 差异
│           │   └── BinderForwarder.kt        # Binder 原语
│           ├── ui/MainActivity.kt            # 改: becomeManager/install → ensureStarted
│           ├── viewmodel/                    # 改: 数据源 → engine
│           ├── theme/ component/ navigation/ util/  # 从 KSU 原样拷贝
│           └── ui/screen/                    # 从 KSU 原样拷贝 (占位骨架已给)
└── engine/                          # ★ Shizuku 源码平铺 (核心, 零改动)
    ├── api/ manager/ server/ starter/        # build.gradle 指向 Shizuku 对应目录
    └── src/test/.../BridgeLogicTest.kt      # 桥接契约测试 (JUnit4, 纯 JVM)
```

## 改动统计

- 外壳改动：**6 处** (Application / MainActivity / Natives / SuperUserVM / ModuleVM / Manifest)
- 桥接新增：**7 文件** (`engine/` 包)
- Shizuku 核心改动：**0**
- KernelSU UI 删减：**0**

## 桥接语义速查

| KernelSU UI 语义 | Shizuku 能力 (真实公开 API) | 落地文件 |
|---|---|---|
| 授权 App (allowSu) | `checkSelfPermission`/`requestPermission` + SP 镜像 | EnginePermissionStore.kt |
| Root/su 原语 | `ShizukuBinderWrapper` + `SystemServiceHelper` | BinderForwarder.kt |
| Module 安装/启用 | `UserServiceArgs` + `bindUserService` | EngineModuleBridge.kt |
| 状态卡片 | `pingBinder()` / `getUid()` / `getServerApiVersion()` | EngineStatus.kt |
| ADB/无线调试启动 | `AdbPairingService` + `ServiceStarter` | EngineServiceConnector.kt |

## 快速验证（无需编译）

```bash
$ python3 scripts/check_references.py
关键桥接 API 命中确认:
  [✓] Shizuku.pingBinder
  [✓] Shizuku.getUid
  [✓] Shizuku.checkSelfPermission
  [✓] Shizuku.requestPermission
  [✓] ShizukuBinderWrapper
  [✓] SystemServiceHelper
  [✓] Shizuku.UserServiceArgs
  [✓] Shizuku.bindUserService
  [✓] Shizuku.addBinderReceivedListener
== 引用解析通过 (无工程内断链) ✅ ==
```

详见 [MIGRATION.md](MIGRATION.md) 与改造方案文档。
