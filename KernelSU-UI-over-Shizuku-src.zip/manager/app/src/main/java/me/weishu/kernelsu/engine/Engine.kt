package me.weishu.kernelsu.engine

import android.content.Context
import rikka.shizuku.Shizuku

/**
 * Engine —— 桥接层单例, 持有 Shizuku Binder / 状态机 / 权限表.
 * 由 KernelSUApplication 在 onCreate 中 init, 对应方案 §4.1.
 *
 * 仅依赖 Shizuku 公开 API (rikka.shizuku.Shizuku), 不侵入 engine/ 核心实现.
 */
object Engine {

    @Volatile
    lateinit var appContext: Context
        private set

    /** 权限存储 (SuperUser 页 "授权 App" 语义落地) */
    val permissionStore: EnginePermissionStore get() = EnginePermissionStore

    /** 模块桥接 (Module 页 → UserService 命令通道) */
    val moduleBridge: EngineModuleBridge get() = EngineModuleBridge

    /** 服务连接器 (自启 / ADB 启动) */
    val serviceConnector: EngineServiceConnector get() = EngineServiceConnector

    /** 状态数据源 (Home / Settings 状态卡片) */
    val status: EngineStatus get() = EngineStatus

    /** 兼容工具 (ADB uid=2000 / ROOT uid=0 差异屏蔽) */
    val compat: ShizukuCompat get() = ShizukuCompat

    /** Binder 调用原语 */
    val binder: BinderForwarder get() = BinderForwarder

    fun init(context: Context) {
        appContext = context.applicationContext

        // 1) 授权存储初始化 (本地镜像 + Shizuku checkSelfPermission)
        EnginePermissionStore.init(context)

        // 2) 注册 Shizuku 生命周期/权限回调 (均为函数式接口, lambda 即可)
        Shizuku.addBinderReceivedListener { Engine.status.refresh() }
        Shizuku.addBinderDeadListener { Engine.status.refresh() }
        Shizuku.addRequestPermissionResultListener { code, result ->
            Engine.permissionStore.onRequestPermissionResult(code, result)
        }

        // 3) 初始状态同步
        status.refresh()
    }
}
