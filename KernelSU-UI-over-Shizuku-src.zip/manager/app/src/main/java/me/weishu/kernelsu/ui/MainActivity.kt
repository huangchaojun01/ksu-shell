package me.weishu.kernelsu.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import me.weishu.kernelsu.engine.Engine
import me.weishu.kernelsu.theme.KernelSUTheme

/**
 * MainActivity —— 外壳入口.
 * 对应方案 §4.1: 仅改 onCreate 前段, Composable 树 (Scaffold / NavHost / 4 页导航) 不动.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ★ 改动点: 原 "val isManager = Natives.becomeManager(pkg); if (isManager) install()"
        //   → 引导 Shizuku 服务, 无内核依赖
        Engine.serviceConnector.ensureStarted()

        setContent {
            KernelSUTheme {
                Scaffold { innerPadding ->
                    AppContent(Modifier, innerPadding)
                }
            }
        }
    }
}

@Composable
private fun AppContent(modifier: Modifier = Modifier, innerPadding: androidx.compose.foundation.layout.PaddingValues) {
    // 原: DestinationsNavHost(NavGraphs.root) —— 四页导航 (Home/SuperUser/Module/Settings)
    // 此处骨架占位, 实际从 KernelSU v3.2.3 拷贝 ui/Main.kt 整体替换即可
}
