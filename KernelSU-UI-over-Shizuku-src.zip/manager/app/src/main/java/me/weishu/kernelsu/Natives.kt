package me.weishu.kernelsu

import me.weishu.kernelsu.engine.Engine

/**
 * Natives —— KernelSU 原生接口桩.
 * 对应方案 §4.2: 保留类/方法签名 (外部 ViewModel 调用方零感知),
 *   方法体由 "kernel ioctl" 改为转发 engine (Shizuku 语义).
 *
 * 原: init { System.loadLibrary("kernelsu") }  ← 已移除, 无 kernel
 */
object Natives {

    // ---- 状态类 (原: ioctl; 现: EngineStatus / ShizukuStateMachine) ----
    fun getVersion(): Int = Engine.status.versionCode
    fun isSafeMode(): Boolean = Engine.status.isSafeMode
    fun isLkmMode(): Boolean = false           // 语义不存在, 固定 false (UI 占位不崩)
    fun isLateLoadMode(): Boolean = false
    val isManager: Boolean = true              // 自身即管理器
    fun isPrBuild(): Boolean = false
    fun requireNewKernel(): Boolean = false    // 永远兼容, 不再弹升级卡

    // ---- allowlist (原: kernel allowlist; 现: Shizuku 授权表) ----
    fun getAllowList(): IntArray = Engine.permissionStore.allowedUids
    fun getSuperuserCount(): Int = Engine.permissionStore.allowedCount

    // ---- App Profile (原: prctl KERNEL_SU_OPTION; 现: engine 权限记录) ----
    fun getAppProfile(key: String?, uid: Int): Profile = Engine.permissionStore.getProfile(uid)
    fun setAppProfile(profile: Profile?): Boolean = Engine.permissionStore.setProfile(profile)
    fun uidShouldUmount(uid: Int): Boolean = Engine.permissionStore.shouldUmount(uid)

    // ---- su 兼容 / kernel umount (映射为 engine 开关) ----
    fun isSuEnabled(): Boolean = Engine.status.suCompatible
    fun setSuEnabled(enabled: Boolean) { Engine.status.suCompatible = enabled }
    fun isKernelUmountEnabled(): Boolean = Engine.status.kernelUmount
    fun setKernelUmountEnabled(enabled: Boolean) { Engine.status.kernelUmount = enabled }

    fun getUserName(uid: Int): String? = Engine.permissionStore.getPackageName(uid)

    // ---- Profile data class (签名原样保留, 字段语义映射) ----
    data class Profile(
        val uid: Int = 0,
        val gid: Int = 0,
        val groups: IntArray = intArrayOf(),
        val capabilities: Long = 0L,
        val sepolicy: String = "",
        val allowSu: Boolean = false,        // ★ "授权 App" 核心标志
        val umountModules: Boolean = false,
        val template: String = "",
        // 桥接扩展 (不影响原有字段)
        val packageName: String = "",
    )
}
