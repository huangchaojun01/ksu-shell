package me.weishu.kernelsu.engine

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import rikka.shizuku.Shizuku

/**
 * EnginePermissionStore —— "授权 App" 语义 → Shizuku 授权持久化.
 * 对应方案 §4.4: KernelSU allowlist (内核) → Shizuku 授权态 + 本地镜像.
 *
 * ★ 仅依赖 Shizuku 公开 API (rikka.shizuku.Shizuku):
 *     - checkSelfPermission(): Int           查询自身是否已授权
 *     - requestPermission(int): Unit        请求授权 (弹 Shizuku 确认框)
 *     - addRequestPermissionResultListener   授权结果回调
 *     - pingBinder(): Boolean                服务存活
 *
 * 授权"列表"在 Shizuku 世界没有独立的管理端 API (授权是 per-calling-UID 的),
 * 因此我们用 SharedPreferences 做本地镜像 (grant/revoke 持久化),
 * 这等价于 KernelSU 的 allowlist, 且符合 "不动 Shizuku 核心" 原则.
 */
object EnginePermissionStore {

    private const val PREFS = "kernelsu_bridge_allowlist"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    // ---- 对应 Natives.getAllowList() / getSuperuserCount() ----
    val allowedUids: IntArray
        get() = prefs.getIntArray("allowed_uids") ?: intArrayOf()

    val allowedCount: Int get() = allowedUids.size

    // -------- "授权 / 撤销" (SuperUser 开关 allowSu) --------

    /** 对应 UI: 为某 App 开启 Root */
    fun grant(packageName: String, uid: Int) {
        // 1) 本地镜像 (持久化, 等价 KernelSU allowlist)
        val set = allowedUids.toMutableSet()
        set.add(uid)
        prefs.edit { putIntArray("allowed_uids", set.toIntArray()) }
        // 2) 记录包名映射 (供 getPackageName)
        prefs.edit { putString("pkg_$uid", packageName) }
        // 3) 触发 Shizuku 运行时授权请求 (弹确认框, 结果在 permission result 回调)
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(REQUEST_CODE_GRANT)
        }
        Engine.status.refresh()
    }

    fun revoke(uid: Int) {
        val set = allowedUids.toMutableSet()
        set.remove(uid)
        prefs.edit { putIntArray("allowed_uids", set.toIntArray()) }
        prefs.edit { remove("pkg_$uid") }
        Engine.status.refresh()
    }

    // -------- Profile (Natives.getAppProfile / setAppProfile 落地) --------

    fun getProfile(uid: Int): Natives.Profile {
        val allowed = allowedUids.contains(uid)
        return Natives.Profile(
            uid = uid,
            allowSu = allowed,
            packageName = prefs.getString("pkg_$uid", "") ?: "",
        )
    }

    fun setProfile(profile: Natives.Profile?): Boolean {
        if (profile == null) return false
        if (profile.allowSu) grant(profile.packageName, profile.uid)
        else revoke(profile.uid)
        return true
    }

    fun shouldUmount(uid: Int): Boolean = getProfile(uid).umountModules
    fun getPackageName(uid: Int): String? =
        prefs.getString("pkg_$uid", null)

    // -------- Shizuku 授权结果回调 --------

    /** 注册到 Shizuku.addRequestPermissionResultListener */
    fun onRequestPermissionResult(requestCode: Int, result: Int) {
        if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Engine.status.refresh()
        }
    }

    private const val REQUEST_CODE_GRANT = 0x4B53_0001u.toInt() // "KS"

    // -------- SharedPreferences 扩展 --------
    private fun SharedPreferences.getIntArray(key: String): IntArray? =
        getString(key, null)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toIntArray()
    private fun SharedPreferences.Editor.putIntArray(key: String, value: IntArray) =
        putString(key, value.joinToString(","))
}

/** Engine.init 中调用, 初始化授权存储 */
fun EnginePermissionStoreInit(context: Context) = EnginePermissionStore.init(context)
