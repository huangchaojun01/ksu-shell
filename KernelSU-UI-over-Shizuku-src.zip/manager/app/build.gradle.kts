plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    // ★ 关键: namespace 锁 KernelSU, 保证最终 APK 是 "KernelSU"
    namespace = "me.weishu.kernelsu"
    compileSdk = 36

    defaultConfig {
        applicationId = "me.weishu.kernelsu"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "3.2.3-bridge"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        aidl = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.viewmodel)
    implementation(libs.androidx.lifecycle.compose)
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling)
    implementation(libs.compose.material3)
    implementation(libs.compose.navigation)
    implementation(libs.androidx.material)
    implementation(libs.kotlinx.coroutines)

    // ★ Shizuku API (核心, 零改动) —— 方案 §2.1 / §5.1
    implementation(libs.shizuku.api)
    implementation(libs.shizuku.provider)

    // engine 模块 (Shizuku manager/server/starter 逻辑类)
    implementation(project(":engine-manager"))
    implementation(project(":engine-server"))
    implementation(project(":engine-starter"))
}
