package me.weishu.kernelsu.navigation

/**
 * 导航路由 (外壳, 原样保留 KernelSU 四页结构).
 * 对应方案 §3.3: 底部导航 Home / SuperUser / Module / Settings.
 */
object NavRoutes {
    const val Home = "home"
    const val SuperUser = "superuser"
    const val Module = "module"
    const val Settings = "settings"
}
