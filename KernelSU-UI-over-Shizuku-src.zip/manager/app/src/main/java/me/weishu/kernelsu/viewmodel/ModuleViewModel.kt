package me.weishu.kernelsu.viewmodel

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import me.weishu.kernelsu.engine.Engine
import me.weishu.kernelsu.engine.ModuleInfo

/**
 * ModuleViewModel —— 模块管理.
 * 对应方案 §4.5: 列表渲染/开关/下载/WebUI (UI) 完全保留,
 *   **仅把 KsuCli shell 调用 → EngineModuleBridge** (每方法约 1 行).
 */
class ModuleViewModel : ViewModel() {

    val modules: MutableState<List<ModuleInfo>> = mutableStateOf(emptyList())

    fun load() {
        // ★ 改动点: 原 KsuCli.lsModules() → EngineModuleBridge.list()
        modules.value = Engine.moduleBridge.list()
    }

    fun install(zipPath: String) {
        // ★ 改动点: 原 KsuCli.exec("ksu module install ...") → EngineModuleBridge.installModule
        Engine.moduleBridge.installModule(zipPath)
    }

    fun setEnabled(id: String, enabled: Boolean) {
        // ★ 改动点
        Engine.moduleBridge.setEnabled(id, enabled)
    }

    fun remove(id: String) {
        // ★ 改动点
        Engine.moduleBridge.remove(id)
    }
}
