package me.weishu.kernelsu.engine

import android.os.IBinder
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/**
 * BinderForwarder —— Binder 调用原语.
 * 对应方案 §4.6: 所有 "原本走 kernel ioctl 的系统交互" 统一走 Shizuku server 转发
 *   (ADB/Root 下以 shell/root 身份 transact).
 */
object BinderForwarder {

    /** 获取系统服务 Binder 并以 shell/root 身份包装 */
    fun <T> getService(name: String, stub: (IBinder) -> T): T {
        val raw = SystemServiceHelper.getSystemService(name)
        return stub(ShizukuBinderWrapper(raw))
    }

    /** 通用 transact 代理 (对应 KernelSU ksuctl/ioctl 语义) */
    fun transactRemote(code: Int, data: ByteArray): ByteArray {
        val binder = Shizuku.getBinder() ?: throw IllegalStateException("Shizuku service not running")
        val wrapped = ShizukuBinderWrapper(binder)
        // parcel 组装 + wrapped.transact(code, parcel, reply, 0)
        // 简化: 子类化实现按需扩展 (see方案 §4.6)
        return ByteArray(0)
    }
}
