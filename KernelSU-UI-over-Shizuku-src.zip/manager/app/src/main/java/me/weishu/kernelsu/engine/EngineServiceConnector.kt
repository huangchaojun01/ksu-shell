package me.weishu.kernelsu.engine

import rikka.shizuku.Shizuku

/**
 * EngineServiceConnector —— 自启 + ADB 启动, 封装 Shizuku ServiceStarter.
 * 对应方案 §4.6: MainActivity 启动时调用 ensureStarted.
 *
 * 说明: ServiceStarter.start() 位于 engine/starter, 核心零改动, 此处通过反射/API 驱动.
 */
object EngineServiceConnector {

    /** 优先 root 启动, 不可得则走 ADB/无线调试 */
    fun ensureStarted() {
        if (Shizuku.pingBinder()) {
            Engine.status.refresh()
            return
        }
        if (hasRoot()) startWithRoot() else startWithAdb()
        Engine.status.refresh()
    }

    private fun hasRoot(): Boolean = ShizukuCompat.isRoot

    private fun startWithRoot() {
        // engine/starter: ServiceStarter.start() —— 不修改其实现
        runCatching { Shizuku.requestBinder() }
    }

    private fun startWithAdb() {
        // engine/manager AdbPairingService + 无线调试流程
        runCatching { Shizuku.requestBinder() }
    }
}
