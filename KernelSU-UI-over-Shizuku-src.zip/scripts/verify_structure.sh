#!/usr/bin/env bash
# 工程结构 & 桥接完整性自检 (不依赖 Android SDK, 纯文件/符号检查)
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "== KernelSU-UI-over-Shizuku 结构自检 =="

# 1. 目录结构
check_dir() { [ -d "$1" ] && echo "  [OK] $1" || { echo "  [MISSING] $1"; exit 1; }; }
check_file() { [ -f "$1" ] && echo "  [OK] $1" || { echo "  [MISSING] $1"; exit 1; }; }

echo "-- 根 --"
check_file settings.gradle
check_file build.gradle
check_file gradle/libs.versions.toml

echo "-- 外壳 (KernelSU UI, 不动) --"
check_dir manager/app/src/main/java/me/weishu/kernelsu/ui
check_dir manager/app/src/main/java/me/weishu/kernelsu/theme
check_dir manager/app/src/main/java/me/weishu/kernelsu/component

echo "-- ★ 桥接层 (唯一新增) --"
check_file manager/app/src/main/java/me/weishu/kernelsu/engine/Engine.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/engine/EnginePermissionStore.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/engine/EngineModuleBridge.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/engine/EngineStatus.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/engine/EngineServiceConnector.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/engine/ShizukuCompat.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/engine/BinderForwarder.kt

echo "-- 外壳改动点 --"
check_file manager/app/src/main/java/me/weishu/kernelsu/KernelSUApplication.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/Natives.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/ui/MainActivity.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/viewmodel/SuperUserViewModel.kt
check_file manager/app/src/main/java/me/weishu/kernelsu/viewmodel/ModuleViewModel.kt
check_file manager/app/src/main/AndroidManifest.xml

echo "-- Engine (Shizuku 核心, 零改动, 源码平铺) --"
check_dir engine/api
check_dir engine/manager
check_dir engine/server
check_dir engine/starter

# 2. 桥接语义引用检查 (grep 关键转发)
echo "-- 桥接引用校验 --"
grep -q "Engine.init" manager/app/src/main/java/me/weishu/kernelsu/KernelSUApplication.kt && echo "  [OK] Application → Engine.init"
grep -q "Engine.serviceConnector.ensureStarted" manager/app/src/main/java/me/weishu/kernelsu/ui/MainActivity.kt && echo "  [OK] MainActivity → ensureStarted"
grep -q "Engine.permissionStore" manager/app/src/main/java/me/weishu/kernelsu/Natives.kt && echo "  [OK] Natives → permissionStore"
grep -q "Engine.moduleBridge" manager/app/src/main/java/me/weishu/kernelsu/viewmodel/ModuleViewModel.kt && echo "  [OK] ModuleVM → moduleBridge"
grep -q "ShizukuSettings.grant" manager/app/src/main/java/me/weishu/kernelsu/engine/EnginePermissionStore.kt && echo "  [OK] grant → ShizukuConfig"
grep -q "bindUserService" manager/app/src/main/java/me/weishu/kernelsu/engine/EngineModuleBridge.kt && echo "  [OK] Module → UserService"

# 3. 主题/包名锁定检查
echo "-- 主题 & 包名锁定 --"
grep -q 'applicationId = "me.weishu.kernelsu"' manager/app/build.gradle.kts && echo "  [OK] applicationId = me.weishu.kernelsu"
grep -q 'namespace = "me.weishu.kernelsu"' manager/app/build.gradle.kts && echo "  [OK] namespace = me.weishu.kernelsu"
grep -q 'android:theme="@style/KernelSUTheme"' manager/app/src/main/AndroidManifest.xml && echo "  [OK] theme = KernelSUTheme"

echo ""
echo "== 自检通过: 桥接层 7 文件齐全, 外壳改动点 6 处, engine 模块就绪 =="
