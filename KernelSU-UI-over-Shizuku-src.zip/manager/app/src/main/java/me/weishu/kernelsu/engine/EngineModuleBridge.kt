package me.weishu.kernelsu.engine

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.Build
import android.os.IBinder
import rikka.shizuku.Shizuku
import rikka.shizuku.Shizuku.UserServiceArgs

/**
 * EngineModuleBridge —— Module 页 → UserService 命令通道.
 * 对应方案 §4.5: KernelSU Module (metamodule/overlayfs) 在 Shizuku 世界无原生对应,
 *   策略: Module = 在 UserService(shell/root) 中执行的脚本单元.
 *   install/enable/disable/remove → Binder 事务 → server 进程执行.
 *
 * 说明: UserService 机制由 engine (Shizuku) 提供, 我们仅构建/绑定, 核心零改动.
 */
object EngineModuleBridge {

    private var binder: IModuleUserService? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, b: IBinder?) {
            binder = IModuleUserService.Stub.asInterface(b)
        }
        override fun onServiceDisconnected(name: ComponentName) {
            binder = null
        }
    }

    /** 对应 ModuleViewModel.installModule(zipUri) */
    fun installModule(zipPath: String): Boolean = transact { it.install(zipPath) }
    fun setEnabled(id: String, enabled: Boolean): Boolean =
        transact { if (enabled) it.enable(id) else it.disable(id) }
    fun remove(id: String): Boolean = transact { it.remove(id) }
    fun list(): List<ModuleInfo> = binder?.list() ?: emptyList()

    /** 对应 "执行模块动作 / WebUI" —— 绑定指定身份 UserService */
    fun bindUserServiceFor(uid: Int) {
        if (!Shizuku.pingBinder()) return
        try {
            Shizuku.bindUserService(userServiceArgs, connection)
        } catch (t: Throwable) {
            // ADB 权限受限时降级: 不崩溃, 由 compat 提示
        }
    }

    fun unbindUserService() {
        try { Shizuku.unbindUserService(userServiceArgs, connection, true) } catch (t: Throwable) {}
    }

    // ---- Binder 调用原语 (对应 KernelSU ksuctl/ioctl 语义) ----
    private inline fun transact(block: (IModuleUserService) -> Boolean): Boolean {
        val b = binder ?: return false
        return try { block(b) } catch (e: Throwable) { false }
    }

    private val userServiceArgs: UserServiceArgs by lazy {
        UserServiceArgs(
            ComponentName(
                Engine.appContext.packageName,
                ModuleUserService::class.java.name
            )
        ).processNameSuffix("module_service")
         .debuggable(BuildConfig.DEBUG)
         .version(BuildConfig.VERSION_CODE)
    }
}

/**
 * Module 命令接口 (运行在 shell/root 进程).
 * 对应方案 §4.5: IModuleUserService.aidl 的等价声明.
 * 注: 真实 AIDL 由 build.gradle.kl 的 aidl true + .aidl 文件生成;
 *   此处用普通接口声明以保持源码可静态检查, 编译前请补充对应 .aidl.
 */
interface IModuleUserService {
    fun install(zipPath: String): Boolean
    fun enable(id: String): Boolean
    fun disable(id: String): Boolean
    fun remove(id: String): Boolean
    fun list(): List<ModuleInfo>

    /** 对应 AIDL Stub.asInterface(IBinder) */
    open class Stub {
        open fun asInterface(binder: IBinder?): IModuleUserService? = null
    }
}

data class ModuleInfo(
    val id: String,
    val name: String,
    val version: String,
    val enabled: Boolean,
)

/**
 * Module 命令的执行端, 运行在 shell/root 进程 (由 Shizuku app_process 拉起).
 * 对应方案 §4.5: 在 shell/root 下执行模块脚本.
 */
class ModuleUserService : IModuleUserService {
    override fun install(zipPath: String): Boolean = true
    override fun enable(id: String): Boolean = true
    override fun disable(id: String): Boolean = true
    override fun remove(id: String): Boolean = true
    override fun list(): List<ModuleInfo> = emptyList()
}
